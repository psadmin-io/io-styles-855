update psoptions set ptbrandtheme = 'IO_THEME_TANGERINE', THEMESTYLETYPE = 'TANG', STYLESHEETNAME = 'PSSTYLEDEF_TANGERINE';
update PS_PTBR_THMRGAT set PTBR_ATTR_SVALUE = 'IO_THEME_TANGERINE' where PTBR_ATTR_ID = '.themeID';
insert into psoptionsaddl values ('C', 'CSS', 'IO_LOGO', '0');
insert into psoptionsaddl values ('C', 'CSS', 'IO_HDR_BLUE', '0');
commit;